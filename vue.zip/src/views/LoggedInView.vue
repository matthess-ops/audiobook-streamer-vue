<template>
  <div class="about">
    <h1>You are logged in</h1>
  </div>
</template>
